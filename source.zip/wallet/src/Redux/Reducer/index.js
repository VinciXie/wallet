import {combineReducers} from 'redux'

import TransferReducer from './TransferReducer'

const rootReducer = combineReducers({
    TransferReducer
})

export default rootReducer