import {QRscanner} from 'react-native-qr-scanner'

export default QRscanner