export default {
    base_url:"http://139.219.133.94:8080/",
    // base_url:"http://139.219.130.112:8080/",
    // base_url:"http://139.217.202.68:8080/",
    version:"v3"
}