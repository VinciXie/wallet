//
//  rn_wallet-Bridging-Header.h
//  rn_wallet
//
//  Created by 袁俊亮 on 2018/7/19.
//  Copyright © 2018年 Facebook. All rights reserved.
//

#import <React/RCTBridgeModule.h>
